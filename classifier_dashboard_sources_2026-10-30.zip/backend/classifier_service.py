"""Independent native classifier inference; never trains or reads repair labels."""
from collections import OrderedDict
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys
import threading
import numpy as np
import pandas as pd

_models=OrderedDict();_model_lock=threading.RLock()


def _number(value):
    if isinstance(value,bool):return None
    try:value=float(value)
    except (TypeError,ValueError):return None
    return value if math.isfinite(value) and 0<=value<=1 else None


def _inside(root,name):
    path=(root/name).resolve()
    if not path.is_relative_to(root.resolve()):raise ValueError('Classifier path leaves model directory')
    return path


def _load(folder):
    folder=Path(folder).resolve();manifest_path=folder/'manifest.json'
    digest=hashlib.sha256(manifest_path.read_bytes()).hexdigest();key=(str(folder),digest)
    with _model_lock:
        if key in _models:_models.move_to_end(key);return _models[key]
        manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
        for name,checksum in manifest.items():
            file=_inside(folder,name)
            if hashlib.sha256(file.read_bytes()).hexdigest()!=checksum:raise ValueError('Изменён файл экспорта классификатора: '+name)
        required={'config.json','classifier.cbm','runtime/__init__.py','runtime/inference.py','runtime/feature_functions.py',
                  'runtime/preparation.py','runtime/regime_evidence.py','runtime/input_grid.py'}
        if not required.issubset(manifest):raise ValueError('Неполный экспорт классификатора')
        namespace='_dashboard_risk_'+hashlib.sha256((str(folder)+digest).encode()).hexdigest()[:20]
        spec=importlib.util.spec_from_file_location(namespace,folder/'runtime/__init__.py',submodule_search_locations=[str(folder/'runtime')])
        module=importlib.util.module_from_spec(spec);sys.modules[namespace]=module
        old=sys.dont_write_bytecode;sys.dont_write_bytecode=True
        try:
            spec.loader.exec_module(module)
            model=module.Model(folder)
        finally:sys.dont_write_bytecode=old
        _models[key]=model
        while len(_models)>4:
            old_key,_=_models.popitem(last=False)
            old_namespace='_dashboard_risk_'+hashlib.sha256((''.join(old_key)).encode()).hexdigest()[:20]
            for name in list(sys.modules):
                if name==old_namespace or name.startswith(old_namespace+'.'):sys.modules.pop(name,None)
        return model


def unavailable(reason,status='unavailable'):
    return dict(status=status,risk=None,label='Нет оценки',reason=str(reason),score=None,threshold=None,confirmed=False)


class ClassifierService:
    def __init__(self,base_dir,data_path,settings):
        self.base=Path(base_dir);self.path=Path(data_path)
        if not self.path.is_absolute():self.path=self.base/self.path
        self.settings=dict(settings or {});self.enabled=self.settings.get('enabled',True)
        if not isinstance(self.enabled,bool):raise ValueError('classifier.enabled must be true or false')
        self.root=Path(self.settings.get('model_dir') or '__classifier_not_configured__')
        if not self.root.is_absolute():self.root=self.base/self.root
        if 'threshold' in self.settings and self.settings['threshold'] is not None and _number(self.settings['threshold']) is None:
            raise ValueError('classifier.threshold: укажите конечное число от 0 до 1')
        self._lock=threading.RLock();self._cache=OrderedDict();self._data=None;self._data_key=None

    def _versions(self):
        if (self.root/'index.json').exists():
            stamp=(self.root/'index.json').stat().st_mtime_ns
            values=json.loads((self.root/'index.json').read_text(encoding='utf-8'))
            folders=[_inside(self.root,row['folder']) for row in values]
        elif (self.root/'config.json').exists():stamp=(self.root/'config.json').stat().st_mtime_ns;folders=[self.root]
        else:raise ValueError('Не найден экспорт классификатора: '+str(self.root))
        result=[]
        for folder in folders:
            config=json.loads((folder/'config.json').read_text(encoding='utf-8'))
            if config.get('version')!='direct-risk-1':raise ValueError('Неподдерживаемый экспорт классификатора')
            if config.get('feature_contract')!='telemetry_only_v1':raise ValueError('Повторите экспорт классификатора в обновлённом 05')
            result.append((pd.Timestamp(config['available_at']),folder,config))
        return sorted(result,key=lambda row:row[0]),stamp

    def _threshold(self,config):
        rule=self.settings.get('threshold_rule','alarm_budget_recall')
        saved=config.get('thresholds',{}).get(rule,{})
        value=_number(saved.get('threshold'))
        if value is not None and saved.get('available',True):return value,rule
        value=_number(config.get('threshold'))
        if value is not None:return value,'saved_default'
        return None,None

    def _select(self,versions,at):
        available=[row for row in versions if row[0]<=at]
        if not available:return None
        explicit=_number(self.settings.get('threshold'))
        if explicit is not None:return (*available[-1],explicit,'configured')
        for candidate in reversed(available):
            value,source=self._threshold(candidate[2])
            if value is not None:return (*candidate,value,source)
        return (*available[-1],.5,'fallback_05')

    def _raw(self,config,unit,data_key):
        import pyarrow.parquet as pq
        spec=config['units'][unit];aliases={**spec['aliases'],**self.settings.get('aliases',{})}
        names=pq.read_schema(self.path).names
        columns=[c for c in names if c=='TimeValue' or aliases.get(str(c).strip(),str(c).strip()) in spec['roles']]
        key=(*data_key,tuple(columns))
        if key!=self._data_key:
            self._data=pd.read_parquet(self.path,columns=columns);self._data_key=key
        return self._data

    def evaluate(self,at=None):
        if not self.enabled:return unavailable('Классификатор отключён','disabled')
        with self._lock:
            try:return self._evaluate(at)
            except Exception as exc:return unavailable(str(exc),'error')
            finally:
                # Keep native weights and small decisions, not a second full
                # telemetry history per boiler/horizon between requests.
                self._data=None;self._data_key=None

    def _evaluate(self,at):
        versions,stamp=self._versions()
        stat=self.path.stat();data_key=(str(self.path),stat.st_mtime_ns,stat.st_size)
        if at is None:
            times=pd.to_datetime(pd.read_parquet(self.path,columns=['TimeValue'])['TimeValue'],errors='coerce')
            at=times.max()
        at=pd.Timestamp(at).floor('h')
        if pd.isna(at):raise ValueError('Нет корректного времени телеметрии')
        cache_key=(str(at),stamp,*data_key)
        if cache_key in self._cache:self._cache.move_to_end(cache_key);return self._cache[cache_key]
        selected=self._select(versions,at)
        if selected is None:return unavailable('На выбранную дату классификатор ещё не был доступен','not_yet_available')
        _,folder,config,threshold,threshold_source=selected
        unit=self.settings.get('unit')
        if not unit and len(config['units'])==1:unit=next(iter(config['units']))
        if unit not in config['units']:raise ValueError('Укажите classifier.unit из списка: '+', '.join(config['units']))
        horizon=int(config['options']['horizon_hours'])
        if self.settings.get('horizon_hours') is not None and int(self.settings['horizon_hours'])!=horizon:
            raise ValueError('Горизонт настройки не совпадает с экспортом')
        persist=float(self.settings.get('persist_hours',config['options'].get('alarm_persist_hours',3)))
        step=pd.Timedelta(config['preparation']['step'])
        points=max(1,int(np.ceil(pd.Timedelta(hours=persist)/step)))
        if persist<=0 or points>168:raise ValueError('classifier.persist_hours: допустимо от одного шага до 168 точек')
        history=[];missing=[]
        # Version and threshold are chosen for every hour, so a model switch
        # never retroactively applies the newest classifier to earlier points.
        groups=[]
        for time in pd.date_range(at-step*(points-1),at,freq=step):
            choice=self._select(versions,time)
            if choice is None:history.append(dict(time=time,score=None,threshold=None));continue
            if groups and groups[-1][0]==choice[1:2]:groups[-1][2].append(time)
            else:groups.append((choice[1:2],choice,[time]))
        for _,choice,times in groups:
            _,path,local_config,local_threshold,_=choice
            if unit not in local_config['units']:
                history.extend(dict(time=t,score=None,threshold=None) for t in times);continue
            local_raw=self._raw(local_config,unit,data_key)
            with _model_lock:
                runtime=_load(path)
                scored,absent=runtime.predict(local_raw,unit,times[-1],start=times[0],aliases=self.settings.get('aliases'))
            missing.extend(absent)
            for time in times:
                score=_number(scored.loc[time,'score']) if time in scored.index else None
                history.append(dict(time=time,score=score,threshold=local_threshold,
                                    mode=str(scored.loc[time,'mode']) if time in scored.index else 'нет данных'))
        history.sort(key=lambda row:row['time']);current=history[-1]
        if current['score'] is None:
            result=unavailable('Недостаточно пригодных измерений или котёл вне режима оценки')
            result.update(horizonHours=horizon,asOf=at.isoformat(),missingSensors=sorted(set(missing)))
        else:
            risk=current['score']>=threshold
            confirmed=len(history)==points and all(p['score'] is not None and p['threshold'] is not None and p['score']>=p['threshold'] for p in history)
            result=dict(status='ok',risk=bool(risk),label='Есть' if risk else 'Нет',reason=None,
                score=current['score'],threshold=threshold,thresholdSource=threshold_source,confirmed=bool(confirmed),
                horizonHours=horizon,asOf=at.isoformat(),availableAt=str(config['available_at']),
                modelVersion=folder.name,scope=config.get('experiment',{}).get('method'),
                scoreStatus=config['score_status'],missingSensors=sorted(set(missing)),persistHours=persist,
                validation=config.get('validation_selection',{}))
        self._cache[cache_key]=result
        while len(self._cache)>4:self._cache.popitem(last=False)
        return result


class ClassifierHeads:
    """Sequential horizons, one primary card; no simultaneous feature matrices."""
    def __init__(self,base_dir,data_path,settings):
        if not isinstance(settings,dict):raise ValueError('classifier must be an object')
        configs=settings.get('models')
        self.primary=settings.get('primary_horizon')
        if self.primary is not None:
            if isinstance(self.primary,bool) or int(self.primary)<=0:raise ValueError('classifier.primary_horizon must be positive')
            self.primary=int(self.primary)
        if configs is None:configs=[settings]
        if not isinstance(configs,list) or not configs:raise ValueError('classifier.models must be nonempty')
        if any(not isinstance(item,dict) for item in configs):raise ValueError('Each classifier.models item must be an object')
        base={k:v for k,v in settings.items() if k not in ('models','primary_horizon')}
        self.heads=[ClassifierService(base_dir,data_path,{**base,**item}) for item in configs]

    def evaluate(self,at=None):
        values=[]
        for head in self.heads:
            values.append(head.evaluate(at))
            if len(self.heads)>1:
                with head._lock:head._data=None;head._data_key=None
        if self.primary is None:chosen=values[0]
        else:chosen=next((v for v in values if v.get('horizonHours')==int(self.primary)),unavailable('Основной горизонт не рассчитан'))
        return {**chosen,'heads':values} if len(values)>1 else chosen
