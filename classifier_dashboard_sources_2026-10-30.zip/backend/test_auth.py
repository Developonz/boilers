# -*- coding: utf-8 -*-
"""
Тест проверки авторизации Keycloak.
Запуск (сервер должен быть запущен): python test_auth.py
"""
import asyncio
import httpx
import json

API_BASE = "http://localhost:8000"


async def test_backend_endpoints():
    """Тестирует все auth-эндпоинты бэкенда."""
    
    print("=" * 60)
    print("🔐 ТЕСТ AUTH ЭНДПОИНТОВ (сервер должен быть запущен)")
    print("=" * 60)
    
    async with httpx.AsyncClient(timeout=15.0, follow_redirects=True) as client:
        
        # 1. /auth/login — должен дать редирект на Keycloak
        print("\n[1] GET /auth/login")
        resp = await client.get(f"{API_BASE}/auth/login", follow_redirects=False)
        location = resp.headers.get("location", "")
        if "kc.enplus.group" in location:
            print(f"    ✅ Редирект на Keycloak: {location[:80]}...")
        else:
            print(f"    ⚠️  Location: {location}")
        
        # 2. /auth/status — проверка статуса без токена
        print("\n[2] GET /auth/status (без токена)")
        resp = await client.get(f"{API_BASE}/auth/status")
        data = resp.json()
        print(f"    authenticated: {data.get('authenticated')}")
        
        # 3. /auth/userinfo — должен вернуть 401 без токена
        print("\n[3] GET /auth/userinfo (без токена)")
        resp = await client.get(f"{API_BASE}/auth/userinfo")
        print(f"    Статус: {resp.status_code} (ожидается 401)")
        if resp.status_code == 401:
            print(f"    ✅ Корректно отклонён без токена")
        else:
            print(f"    ⚠️  Ответ: {resp.text}")
        
        # 4. GET /auth/callback — симулируем callback
        # (без реального кода от Keycloak — просто проверяем что endpoint отвечает)
        print("\n[4] GET /auth/callback (без code — ожидается 400)")
        resp = await client.get(f"{API_BASE}/auth/callback")
        print(f"    Статус: {resp.status_code} (ожидается 400)")
        if resp.status_code >= 400:
            print(f"    ✅ Эндпоинт обрабатывает отсутствующий code")
        
        # 5. Проверяем, есть ли в callback HTML токены
        print("\n[5] Проверка HTML callback — ищем подстановку токенов")
        resp = await client.get(f"{API_BASE}/auth/callback")
        html = resp.text
        # Ищем JavaScript который читает токен
        if "var accessToken = '" in html or "var accessToken = \"" in html:
            print(f"    ✅ Токен подставляется сервером в JavaScript (без URL-params)")
        elif "params.get('access_token')" in html:
            print(f"    ❌ Токен читается из URL-параметров (НЕПРАВИЛЬНО)")
        else:
            print(f"    ℹ️  HTML содержит JS, нужно вручную проверить")
        
        # 6. Выводим URL для ручного тестирования
        print("\n" + "=" * 60)
        print("📋 РУЧНОЕ ТЕСТИРОВАНИЕ В БРАУЗЕРЕ:")
        print("=" * 60)
        print(f"""
1. Откройте: http://localhost:8000/auth/login
   → Вас должно перенаправить на Keycloak SSO
2. Войдите в Keycloak
3. Keycloak вернёт вас на /auth/callback?code=...
4. Проверьте DevTools → Application → Cookies → localhost:8000
   Там должны появиться:
   • access_token (строка вида eyJ...)
   • refresh_token
5. Затем откройте DevTools Console и выполните:
   fetch('/auth/userinfo', {{ headers: {{ 'Authorization': 'Bearer ' + document.cookie.match('access_token=([^;]*)')?.[1] }} }}).then(r=>r.json()).then(console.log)
   Должен вернуться JSON с данными пользователя
6. Или просто обновите страницу — /auth/userinfo вызывается автоматически
        """)


async def simulate_callback_html():
    """
    Показывает, какой HTML отдаёт /auth/callback сейчас.
    """
    print("\n" + "=" * 60)
    print("📄 HTML СТРАНИЦЫ /auth/callback")
    print("=" * 60)
    
    async with httpx.AsyncClient(timeout=10.0) as client:
        resp = await client.get(f"{API_BASE}/auth/callback")
        html = resp.text
        # Выводим только script секцию
        if "<script>" in html:
            start = html.index("<script>")
            end = html.index("</script>", start) + 9
            script = html[start:end]
            print("\nScript block:")
            print(script[:600])
            if "params.get('access_token')" in script:
                print("\n❌ БАГ: токен читается из URL-параметров!")
                print("   Нужно исправить: var accessToken = params.get('access_token')")
                print("   Правильно: var accessToken = '{access_token}'")
            elif "var accessToken = '" in html or 'var accessToken = "' in html:
                print("\n✅ OK: токен подставляется сервером")


if __name__ == "__main__":
    import sys
    asyncio.run(simulate_callback_html())
    print()
    asyncio.run(test_backend_endpoints())
