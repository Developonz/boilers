"""Operating labels from the same daily CSV snapshots used by opc_to_wide."""
from __future__ import annotations
import ast
import bisect
import json
from pathlib import Path
import re
import threading
import pandas as pd


def _json(value):
    for _ in range(3):
        if isinstance(value,(list,dict)) or value is None:return value
        if not isinstance(value,str) or not value.strip():return None
        try:value=json.loads(value)
        except (ValueError,TypeError):
            try:value=ast.literal_eval(value)
            except (ValueError,SyntaxError):return None
    return value if isinstance(value,(list,dict)) else None


def _unit(value):
    value=re.sub(r'\s+',' ',str(value or '').upper().translate(str.maketrans('KAT','КАТ')))
    match=re.match(r'^(?:КА|К|КОТЛОАГРЕГАТ|КОТЕЛ|КОТЁЛ)\s*[-–—№ ]*0*(\d+)(?=\D|$)',value)
    return 'К-'+str(int(match[1])) if match else None


def _station(value):
    return re.sub(r'[\s_–—-]+','',str(value or '').casefold())


def operating_label(equipment,at,parse_time):
    """Priority is identical to the user's UI, including strict null penalty."""
    code=str(equipment.get('Состояние') or '').strip()
    repairs=_json(equipment.get('Ремонты')) or []
    if isinstance(repairs,dict):repairs=[repairs]
    candidates=[]
    for repair in repairs:
        if not isinstance(repair,dict):continue
        created=parse_time(repair.get('Дата создания'))
        if created is not None and created>at:continue
        candidates.append((created if created is not None else pd.Timestamp.min,repair))
    latest=max(candidates,key=lambda row:row[0])[1] if candidates else None
    if code=='Вкл':state,label,icon='working','Работа','in-work-icon'
    elif latest and latest.get('Категория ремонта')=='Плановый' and 'Штраф' in latest and latest['Штраф'] is None:
        state,label,icon='planned_no_penalty','Плановый ремонт (без штрафов)','in-work-icon'
    elif code=='ИСП':state,label,icon='testing','Испытания','search-icon'
    elif code=='ХР':state,label,icon='cold_reserve','Холодный резерв','cold-reserve-icon'
    elif code=='ЗРР':state,label,icon='restricted','Работа с ограничениями','declarated-work-icon'
    elif code:state,label,icon='repair','Аварийный ремонт / Плановый ремонт (со штрафами)','repair-icon'
    else:return None
    return dict(operatingState=state,operatingStateLabel=label,operatingStateIcon=icon,
                operatingStateCode=code,operatingStateSource='repairs',
                latestRepairNumber=str(latest.get('Номер заявки') or '') if latest else None)


class RepairSnapshots:
    def __init__(self,base_dir,path='',shift_hours=5,max_age_hours=24,timezone='Asia/Irkutsk',allow_single_station=False):
        self.path=Path(path) if path else None
        if self.path and not self.path.is_absolute():self.path=Path(base_dir)/self.path
        self.shift_hours=float(shift_hours);self.max_age_hours=float(max_age_hours)
        if self.max_age_hours<=0:raise ValueError('REPAIRS_MAX_AGE_HOURS must be positive')
        self.timezone=timezone;self.allow_single_station=allow_single_station
        self.version=None;self._records={};self._stations=set();self._error=None;self._lock=threading.RLock()

    def timestamp(self,value):
        if value is None or str(value).strip() in ('','NaT','None'):return None
        text=str(value).strip()
        match=re.match(r'^(\d{1,2}):(\d{2})\s+(\d{1,2})\.(\d{1,2})\.(\d{2,4})$',text)
        try:
            if match:
                hour,minute,day,month,year=map(int,match.groups())
                t=pd.Timestamp(year=year+2000 if year<100 else year,month=month,day=day)+pd.Timedelta(hours=hour,minutes=minute)
            else:t=pd.to_datetime(text,format='mixed',dayfirst=not bool(re.match(r'^\d{4}-',text)),errors='coerce')
            if pd.isna(t):return None
            if t.tzinfo is not None:return t.tz_convert(self.timezone).tz_localize(None)
            return t+pd.Timedelta(hours=self.shift_hours)
        except (ValueError,TypeError,OverflowError):return None

    def _reload(self):
        if self.path is None:self.version=('disabled',);return
        try:
            stat=self.path.stat();version=(str(self.path),stat.st_mtime_ns,stat.st_size)
        except OSError:
            self.version=('missing',str(self.path));self._records={};self._error='Не найден файл заявок: '+str(self.path);return
        if version==self.version:return
        self.version=version;self._records={};self._stations=set();self._error=None
        try:
            raw=self.path.read_bytes()
            try:text=raw.decode('utf-8-sig')
            except UnicodeDecodeError:text=raw.decode('cp1251')
            from io import StringIO
            import csv
            separator=csv.Sniffer().sniff(text[:8192],delimiters=';,\t|').delimiter
            frame=pd.read_csv(StringIO(text),sep=separator,dtype=str,keep_default_na=False)
            frame.columns=[c.strip().strip('"').lstrip('\ufeff') for c in frame]
            if not {'Дата','Оборудование'}.issubset(frame):raise ValueError('Нужны столбцы Дата и Оборудование (JSON), как в opc_to_wide')
            invalid=0
            for row in frame.to_dict('records'):
                date=self.timestamp(row['Дата'])
                if date is None:invalid+=1;continue
                station=_station(row.get('ОбъектПУ',''));self._stations.add(station)
                payload=_json(row['Оборудование'])
                if payload is None:invalid+=1;continue
                queue=list(payload) if isinstance(payload,list) else [payload]
                while queue:
                    equipment=queue.pop(0)
                    if not isinstance(equipment,dict):continue
                    name=equipment.get('Оборудование')
                    if isinstance(name,(list,dict)):
                        queue.extend(name if isinstance(name,list) else [name]);continue
                    unit=_unit(name)
                    if unit:self._records.setdefault((station,unit),[]).append((date,equipment))
            for key,records in self._records.items():
                records.sort(key=lambda item:item[0]);self._records[key]=([r[0] for r in records],records)
            if invalid:self._error=f'В файле заявок пропущено некорректных строк: {invalid}'
            if not self._records:raise ValueError('В файле нет распознанных снимков котлов')
        except Exception as exc:
            self._records={};self._error='Не удалось прочитать заявки: '+str(exc)

    def lookup(self,tpp,unit,at):
        with self._lock:
            self._reload()
            result=dict(operatingStateWarning=self._error,operatingStateSource='telemetry')
            if self.path is None:return result
            stations={_station(tpp.get('id')),_station(tpp.get('name'))}
            if unit.get('repairStation'):stations={_station(unit['repairStation'])}
            matched=stations&self._stations
            if not matched and self.allow_single_station and len(self._stations)==1 and not unit.get('repairStation'):
                matched=self._stations
            names=[unit.get('repairUnit'),unit.get('name'),unit.get('id')]
            keys={_unit(name) for name in names if name}-{None}
            found=[];at=pd.Timestamp(at)
            for station in matched:
                for key in keys:
                    data=self._records.get((station,key))
                    if data:
                        index=bisect.bisect_right(data[0],at)-1
                        if index>=0:found.append(data[1][index])
            if not found:
                result['operatingStateWarning']=self._error or 'Нет снимка заявок для выбранного котла и даты'
                return result
            snapshot,equipment=max(found,key=lambda row:row[0])
            if at-snapshot>pd.Timedelta(hours=self.max_age_hours):
                result['operatingStateWarning']='Снимок заявок устарел для выбранной даты';return result
            label=operating_label(equipment,at,self.timestamp)
            if label:
                result.update(label,operatingStateAsOf=snapshot.isoformat())
            else:result['operatingStateWarning']='В снимке нет кода состояния оборудования'
            return result
