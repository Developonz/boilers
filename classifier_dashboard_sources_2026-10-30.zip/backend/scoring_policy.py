"""Dashboard inference policy; loaded exports on disk are never modified."""
from functools import wraps
import inspect
import os
import sys


def mask_spikes_enabled():
    return os.getenv('MODEL_MASK_SPIKES','false').strip().lower() in {'1','true','on','yes'}


def install_scoring_policy(model,module):
    """Disable only spike rejection in legacy/v4 cleaners and modern rule sets."""
    if mask_spikes_enabled():return
    seen=set();namespaces=set()

    def patch_namespace(namespace):
        if id(namespace) in namespaces:return
        namespaces.add(id(namespace))
        original=namespace.get('causal_clean_numeric')
        if not callable(original) or getattr(original,'_dashboard_keep_spikes',False):return
        parameters=inspect.signature(original).parameters
        if 'spike_factor' not in parameters:return
        @wraps(original)
        def keep_spikes(*args,**kwargs):
            if 'mask_spikes' in parameters:kwargs['mask_spikes']=False
            else:kwargs['spike_factor']=float('inf')
            return original(*args,**kwargs)
        keep_spikes._dashboard_keep_spikes=True
        namespace['causal_clean_numeric']=keep_spikes

    def visit(core):
        if core is None or id(core) in seen:return
        seen.add(id(core))
        owner=sys.modules.get(core.__class__.__module__)
        if owner:patch_namespace(vars(owner))
        for name in ('_prepare','_inputs','score','score_raw'):
            method=getattr(core,name,None)
            function=getattr(method,'__func__',method)
            namespace=getattr(function,'__globals__',None)
            if namespace is not None:patch_namespace(namespace)
        for name in ('cfg','config'):
            cfg=getattr(core,name,None)
            if not isinstance(cfg,dict):continue
            if isinstance(cfg.get('causal_cleaning'),dict):
                cfg['causal_cleaning']={**cfg['causal_cleaning'],'spike_factor':float('inf')}
            if 'CLEAN_SPIKE_FACTOR' in cfg:cfg['CLEAN_SPIKE_FACTOR']=float('inf')
        rules=getattr(core,'rules',None)
        if isinstance(rules,dict) and ('defaults' in rules or 'sensors' in rules):
            rules.setdefault('defaults',{})['mask_spikes']=False
            for rule in rules.get('sensors',{}).values():rule['mask_spikes']=False
        for name in ('core','stage1','stage2','model'):visit(getattr(core,name,None))
        members=getattr(core,'members',[]) or []
        if isinstance(members,dict):members=members.values()
        for member in members:visit(member[0] if isinstance(member,tuple) else member)

    patch_namespace(vars(module));visit(model)
