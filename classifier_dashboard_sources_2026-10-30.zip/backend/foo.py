src = 'auth/security.py'
with open(src, 'rb') as f:
    raw = f.read()

for enc in ('cp1251', 'cp1252', 'latin-1', 'cp866'):
    try:
        text = raw.decode(enc)
        with open(src, 'w', encoding='utf-8') as out:
            out.write(text)
        print(f'Converted from {enc}')
        break
    except UnicodeDecodeError:
        continue