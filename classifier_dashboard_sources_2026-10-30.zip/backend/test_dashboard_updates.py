"""Focused read-only-data checks: repair snapshots and preserving sensor spikes."""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import ast,csv,json,os,tempfile,unittest,threading
from collections import OrderedDict
import numpy as np
import pandas as pd
from repair_states import RepairSnapshots,operating_label
from inference_acceleration import fast_causal_clean_numeric
from scoring_policy import install_scoring_policy


def write_snapshots(path,items,station='НИТЭЦ'):
    with Path(path).open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.writer(f,delimiter=';');writer.writerow(['Дата','ОбъектПУ','Оборудование'])
        for date,equipment in items:writer.writerow([date,station,json.dumps([equipment],ensure_ascii=False)])


class DashboardUpdatesTests(unittest.TestCase):
    def test_classifier_card_can_be_served_when_regressor_is_unavailable(self):
        source=ast.parse((Path(__file__).parent/'main.py').read_text(encoding='utf-8'))
        node=next(n for n in source.body if isinstance(n,ast.FunctionDef) and n.name=='get_dashboard_data')
        node.decorator_list=[]
        program=ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),node],type_ignores=[])
        class HttpError(Exception):
            def __init__(self):self.status_code=503;self.detail='regressor unavailable'
        def call(*args):raise HttpError()
        at=pd.Timestamp('2025-01-01')
        risk={'status':'ok','risk':True,'label':'Есть','asOf':at.isoformat()}
        boiler=SimpleNamespace(unit={'id':'1','name':'К-1'},tpp={'id':'t','name':'ТЭЦ'},
            classifier=SimpleNamespace(evaluate=lambda at:risk),
            service=SimpleNamespace(clamp=lambda value:at,data_range=lambda:{}))
        ns=dict(pd=pd,Query=lambda *a,**k:None,check_selection=lambda *args:boiler,service_call=call,
                get_bundle=None,parse_at=lambda at:None,HTTPException=HttpError,DATA_SOURCE='hourly',
                classifier_alert=lambda risk:None,
                DataUnavailable=RuntimeError,REPAIRS=SimpleNamespace(lookup=lambda *args:{}),
                empty_unit=lambda *args:{'healthScore':None})
        exec(compile(ast.fix_missing_locations(program),'dashboard_endpoint','exec'),ns)
        payload=ns['get_dashboard_data']()
        self.assertTrue(payload['overview']['classifier']['risk'])
        self.assertIsNone(payload['summary']['healthScore'])

    def test_bundle_cache_refreshes_state_when_only_repair_file_changes(self):
        source=ast.parse((Path(__file__).parent/'main.py').read_text(encoding='utf-8'))
        node=next(n for n in source.body if isinstance(n,ast.FunctionDef) and n.name=='get_bundle')
        program=ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),node],type_ignores=[])
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'repairs.csv'
            equip={'Оборудование':'К-5','Состояние':'ХР'}
            write_snapshots(path,[('2025-01-01',equip)])
            repairs=RepairSnapshots(tmp,path,shift_hours=0)
            ev=SimpleNamespace(at=pd.Timestamp('2025-01-01 12:00'))
            boiler=SimpleNamespace(key=('n','5'),tpp={'name':'НИТЭЦ'},unit={'name':'К-5'},
                                   service=SimpleNamespace(evaluate=lambda at:ev,history_h=100))
            ns=dict(pd=pd,REPAIRS=repairs,FLEET=SimpleNamespace(boilers=[boiler],select=lambda:boiler),
                    classifier_unavailable=lambda *args:{'status':'disabled','risk':None},
                    classifier_alert=lambda risk:None,
                    _bundle_cache=OrderedDict(),_bundle_lock=threading.Lock(),
                    build_bundle=lambda ev,boiler,state:{'ev':ev,'state':state,'summary':{},'alerts':[]})
            exec(compile(ast.fix_missing_locations(program),'get_bundle','exec'),ns)
            original=ns['get_bundle'](None)
            self.assertEqual(original['state']['operatingState'],'cold_reserve')
            self.assertIs(ns['get_bundle'](None),original)
            write_snapshots(path,[('2025-01-01',{**equip,'Состояние':'Вкл'})])
            stat=path.stat();os.utime(path,ns=(stat.st_atime_ns,stat.st_mtime_ns+10_000_000))
            changed=ns['get_bundle'](None)
            self.assertIsNot(changed,original)
            self.assertEqual(changed['state']['operatingState'],'working')

    def test_labels_follow_supplied_priority_and_strict_null(self):
        at=pd.Timestamp('2025-01-02');parse=lambda value:pd.Timestamp(value) if value else None
        plan={'Дата создания':'2025-01-01','Категория ремонта':'Плановый','Штраф':None}
        for code,state in [('Вкл','working'),('ИСП','testing'),('ХР','cold_reserve'),('ЗРР','restricted'),('АР','repair')]:
            self.assertEqual(operating_label({'Состояние':code},at,parse)['operatingState'],state)
        self.assertEqual(operating_label({'Состояние':'ХР','Ремонты':[plan]},at,parse)['operatingState'],'planned_no_penalty')
        self.assertEqual(operating_label({'Состояние':'Вкл','Ремонты':[plan]},at,parse)['operatingState'],'working')
        for penalty in [0,'',1]:
            p={**plan,'Штраф':penalty}
            self.assertEqual(operating_label({'Состояние':'АР','Ремонты':[p]},at,parse)['operatingState'],'repair')
        p={k:v for k,v in plan.items() if k!='Штраф'}
        self.assertEqual(operating_label({'Состояние':'АР','Ремонты':[p]},at,parse)['operatingState'],'repair')

    def test_csv_snapshot_selection_shift_and_future_changes(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'Ремонты_НИТЭЦ.csv'
            write_snapshots(path,[('01.01.2025',{'Оборудование':'КА-5','Состояние':'Вкл'}),
                                  ('2025-01-02',{'Оборудование':'К-5','Состояние':'ХР'})])
            service=RepairSnapshots(tmp,path,shift_hours=5)
            args=({'id':'n','name':'НИТЭЦ'},{'id':'5','name':'КА-5'})
            self.assertEqual(service.lookup(*args,'2025-01-02 04:00')['operatingState'],'working')
            self.assertEqual(service.lookup(*args,'2025-01-02 06:00')['operatingState'],'cold_reserve')
            self.assertEqual(service.lookup(*args,'2025-01-04')['operatingStateSource'],'telemetry')

    def test_latest_repair_and_future_creation(self):
        service=RepairSnapshots('.',shift_hours=0)
        repairs=[{'Дата создания':'2025-01-01','Категория ремонта':'Аварийный','Штраф':1},
                 {'Дата создания':'2025-01-03','Категория ремонта':'Плановый','Штраф':None}]
        equip={'Состояние':'ХР','Ремонты':repairs}
        self.assertEqual(operating_label(equip,pd.Timestamp('2025-01-02'),service.timestamp)['operatingState'],'cold_reserve')
        self.assertEqual(operating_label(equip,pd.Timestamp('2025-01-04'),service.timestamp)['operatingState'],'planned_no_penalty')

    def test_repair_file_reload_and_station_isolation(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'repairs.csv'
            equip={'Оборудование':'KA-5','Состояние':'ХР'}
            write_snapshots(path,[('2025-01-01',equip)])
            service=RepairSnapshots(tmp,path,shift_hours=0)
            self.assertEqual(service.lookup({'name':'Другая ТЭЦ'},{'name':'К-5'},'2025-01-01 12:00')['operatingStateSource'],'telemetry')
            self.assertEqual(service.lookup({'name':'НИТЭЦ'},{'name':'К-5'},'2025-01-01 12:00')['operatingState'],'cold_reserve')
            old=service.version
            write_snapshots(path,[('2025-01-01',{**equip,'Состояние':'ЗРР'})])
            stat=path.stat();os.utime(path,ns=(stat.st_atime_ns,stat.st_mtime_ns+10_000_000))
            self.assertEqual(service.lookup({'name':'НИТЭЦ'},{'name':'К-5'},'2025-01-01 12:00')['operatingState'],'restricted')
            self.assertNotEqual(old,service.version)

    def test_corrupt_file_has_explicit_fallback(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'repairs.csv';path.write_text('wrong;header\n1;2',encoding='utf-8')
            result=RepairSnapshots(tmp,path).lookup({'name':'НИТЭЦ'},{'name':'К-5'},'2025-01-01')
            self.assertEqual(result['operatingStateSource'],'telemetry')
            self.assertIn('прочитать',result['operatingStateWarning'])

    def test_spikes_remain_but_frozen_segments_are_still_masked(self):
        ix=pd.date_range('2025-01-01',periods=260,freq='h')
        raw=pd.DataFrame({'s':np.sin(np.arange(260)*.7)},index=ix)
        raw.iloc[150,0]+=100;raw.iloc[220:,0]=5.
        clean,masks=fast_causal_clean_numeric(raw,np.ones(260,bool),['s'],min_history_h=24,mask_spikes=False)
        self.assertTrue(masks['spikes'].iloc[150,0])
        self.assertEqual(clean.iloc[150,0],raw.iloc[150,0])
        self.assertTrue(pd.isna(clean.iloc[-1,0]))
        old,_=fast_causal_clean_numeric(raw,np.ones(260,bool),['s'],mask_spikes=True)
        self.assertTrue(pd.isna(old.iloc[150,0]))

    def test_export_cleaner_policy_works_with_acceleration_disabled(self):
        def legacy(frame,running,columns,spike_factor=8.,**kwargs):
            return fast_causal_clean_numeric(frame,running,columns,spike_factor=spike_factor,mask_spikes=True,**kwargs)
        module=SimpleNamespace(causal_clean_numeric=legacy)
        core=SimpleNamespace(cfg={'causal_cleaning':{'spike_factor':8.}},members=[])
        with patch.dict(os.environ,{'MODEL_ACCELERATION':'0','MODEL_MASK_SPIKES':'false'}):
            install_scoring_policy(core,module)
            ix=pd.date_range('2025-01-01',periods=100,freq='h')
            raw=pd.DataFrame({'s':np.sin(np.arange(100))},index=ix);raw.iloc[80,0]=100.
            clean,_=module.causal_clean_numeric(raw,np.ones(100,bool),['s'])
            self.assertEqual(clean.iloc[80,0],100.)
            self.assertTrue(np.isinf(core.cfg['causal_cleaning']['spike_factor']))


if __name__=='__main__':unittest.main()
